--made in python by kurt :P--

!BEFORE USING!

Turn off your antivirus, because due to how most malware creators pack their malware in pyinstaller, most antiviruses will flag pyinstaller programs as a malware and instantly delete them. So unless you want to use this program, turn off your antivirus! trust me, I did NOT put a virus in this program, perhaps smirk smirk tehee.

How to use:

Copy URL from website (Youtube,Instagram,Facebook)

Paste it in the entry box

Click one of the buttons

Profit

Toodles ~ Kurt